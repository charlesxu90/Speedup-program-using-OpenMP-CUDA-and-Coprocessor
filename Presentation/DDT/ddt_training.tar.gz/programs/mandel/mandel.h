
int mandel(double x, double y);
