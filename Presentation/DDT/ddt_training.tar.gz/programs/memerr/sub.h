void Check_free (int length, int * data);
void Check_pointer (int length, int * data);
