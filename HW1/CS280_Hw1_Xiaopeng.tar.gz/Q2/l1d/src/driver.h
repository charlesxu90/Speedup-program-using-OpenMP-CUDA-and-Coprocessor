/*
 * driver.h
 *
 *  Created on: Dec 8, 2012
 *      Author: malastm
 */

#ifndef DRIVER_H_
#define DRIVER_H_

#define PRINT_TIME_DETAILS (0)

extern void parse_args (int argc, char** argv, Parameters *);
extern void print_param(Parameters);

#endif /* DRIVER_H_ */
